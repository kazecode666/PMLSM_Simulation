# PMLSM MIL 仿真包（R2023b 格式）

本包从 2026-09-07 当前磁盘上的模型重新导出，保留主模型与控制核心的 Model Reference 关联。没有使用源目录的 `.slx.r2023b` 历史文件。

## 在另一台电脑上使用

1. 完整解压 ZIP 到一个本地可写目录，例如 `D:\PMLSM_MIL_R2023b`。不要在 ZIP 内直接打开模型。
2. 启动 MATLAB R2023b，将“当前文件夹”切换到解压后的 `PMLSM_MIL_R2023b` 文件夹。
3. 在命令行运行 `start_PMLSM_MIL`，随后在打开的主模型中点击 Run。
4. 首次移植验证可运行 `out = check_PMLSM_MIL;`，成功后会打印 PASS，并返回仿真结果。

需要安装并具有可用许可证：MATLAB、Simulink、Stateflow、Motor Control Blockset。
当前主仿真的依赖分析没有列出 C2000 支持包、Embedded Coder、Simscape 或 Simscape Electrical。

`start_PMLSM_MIL` 会切换到包目录、添加包目录到搜索路径，并把仿真缓存放到包内 `work` 目录。原初始化脚本包含 `clear; clc;`，启动和模型初始化会清空 MATLAB 基础工作区变量，请先保存需要保留的工作区数据。
如果已打开其他目录下的同名模型，先自行保存并关闭它们，再启动本包。

## 包内文件与依赖关系

```text
PMLSM_MIL_ControlCore_Sim.slx
  ├─ Model Reference → PMLSM_ControlCore_Block.slx
  └─ InitFcn
      ├─ init_PMLSM_control_params.m
      │   └─ PMSLM_Init_Params_MBDL4.m
      ├─ init_PMLSM_plant_params.m
      └─ init_PMLSM_mil_test_params.m
```

`init_PMLSM_MIL_params.m` 是上述三层初始化的统一入口。
`PMSLM_Init_Params_MBDL4.m` 虽然名称来自实机工程，但仿真控制参数仍依赖它，因此必须保留；它不要求同时携带代码生成模型。

没有打包 `PMSLM_Close_Loop_MBDL4.slx`、硬件备份模型、旧仿真日志、自动生成代码、`slprj`、`.slxc`、历史导出文件，以及模型重建/布局修改脚本。
`PMLSM_MIL_Library_Sim.slx` 和 `AHC_deadtime_waveform_viewer.slx` 不在本次主仿真的依赖链中，也未打包。
本包针对主 MIL 模型的交互运行；历史参数扫描、论文绘图和诊断批处理脚本不属于此独立运行包。

## 当前默认工况

与打包时原文件一致：仿真 7 s；MIL_Mode=1；电流控制模式 2（DPCC）；静态电流阶跃启用；电流注入幅值 1 A；Plant_Input_Mode=2（duty→逆变器→对象）；理想平均逆变器；死区补偿关闭；半采样 PWM 更新延迟。

简单工况和控制模式在 `init_PMLSM_mil_test_params.m` 中修改，对象参数在 `init_PMLSM_plant_params.m` 中修改。主模型每次初始化会重新运行初始化脚本，因此只在基础工作区手动改变量可能会被覆盖。

## 版本与验证边界

两个模型均由 MATLAB R2026a Update 5 使用 `Simulink.exportToVersion(...,'R2023b')` 重新导出。保留用户库和工具箱链接，未手动改写控制算法、模块布局、连线或初始化参数。导出器自动将 Park / Inverse Park Transform 的库路径映射到旧版 `mcbcontrolslib`，并将 Function-Call Generator 转为旧版库块表示；这些是版本兼容转换。

本机只安装 R2026a，不能在本机声称已通过 R2023b 实际运行。详细本机验证结果见 `VALIDATION.txt`。接收电脑请执行 `check_PMLSM_MIL` 完成 R2023b 环境验证。

MathWorks 导出接口说明：https://www.mathworks.com/help/simulink/slref/simulink.exporttoversion.html
