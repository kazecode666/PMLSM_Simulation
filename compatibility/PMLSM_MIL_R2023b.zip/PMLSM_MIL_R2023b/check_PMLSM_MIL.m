function out = check_PMLSM_MIL
% Run this on the receiving computer to verify the full default simulation.
start_PMLSM_MIL;
root = fileparts(mfilename('fullpath'));
models = {'PMLSM_MIL_ControlCore_Sim','PMLSM_ControlCore_Block'};
for k=1:numel(models)
    assert(strcmpi(which(models{k}),fullfile(root,[models{k} '.slx'])), ...
        'Model does not resolve inside this package: %s',models{k});
end
in = Simulink.SimulationInput(models{1});
in = in.setModelParameter('StopTime','7','ReturnWorkspaceOutputs','on');
out = sim(in);
assert(abs(out.tout(end)-7)<1e-9,'Simulation did not reach 7 seconds.');
assert(out.logsout.numElements>0,'No logged signals were produced.');
fprintf('PASS: default MIL simulation completed to %.6f s on %s.\n',out.tout(end),version);
end
