function start_PMLSM_MIL
% Open the portable MIL simulation. Run from the extracted package folder.
% The original initialization script clears variables in the base workspace.
root = fileparts(mfilename('fullpath'));
models = {'PMLSM_MIL_ControlCore_Sim','PMLSM_ControlCore_Block'};
for k=1:numel(models)
    if bdIsLoaded(models{k})
        loadedFile = get_param(models{k},'FileName');
        assert(strcmpi(loadedFile,fullfile(root,[models{k} '.slx'])), ...
            'A same-named model from another folder is open. Save and close it first: %s',loadedFile);
    end
end
installed = ver;
required = {'MATLAB','Simulink','Stateflow','Motor Control Blockset'};
for k=1:numel(required)
    assert(any(strcmp({installed.Name},required{k})), ...
        'Required product is not installed: %s',required{k});
end
cd(root);
addpath(root,'-begin');
Simulink.fileGenControl('set','CacheFolder',fullfile(root,'work','cache'), ...
    'CodeGenFolder',fullfile(root,'work','codegen'),'createDir',true);
evalin('base','init_PMLSM_MIL_params;');
open_system(models{1});
fprintf('MIL package: %s\nMATLAB: %s\n',root,version);
fprintf('Ready. Click Run in Simulink. Default simulation duration: 7 s.\n');
end
